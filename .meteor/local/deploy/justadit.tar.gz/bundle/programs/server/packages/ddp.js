(function () {

/* Imports */
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;



/* Exports */
Package._define("ddp", {
  DDP: DDP,
  DDPServer: DDPServer
});

})();
