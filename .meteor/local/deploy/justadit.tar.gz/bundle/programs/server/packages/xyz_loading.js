(function () {



/* Exports */
Package._define("xyz:loading");

})();
