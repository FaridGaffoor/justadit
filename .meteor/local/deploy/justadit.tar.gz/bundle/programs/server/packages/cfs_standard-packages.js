(function () {



/* Exports */
Package._define("cfs:standard-packages");

})();
