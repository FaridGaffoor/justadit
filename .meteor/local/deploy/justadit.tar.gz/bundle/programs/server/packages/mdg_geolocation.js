(function () {



/* Exports */
Package._define("mdg:geolocation");

})();
